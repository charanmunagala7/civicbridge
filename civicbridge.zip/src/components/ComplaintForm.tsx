import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { MapPin, Send, Loader2, X, CheckCircle2, User } from 'lucide-react';
import { collection, addDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { useAuth } from '../AuthContext';
import { CATEGORIES, ComplaintCategory } from '../types';
import { cn } from '../lib/utils';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return new Error(JSON.stringify(errInfo));
}

interface ComplaintFormData {
  name: string;
  category: ComplaintCategory;
  description: string;
}

export const ComplaintForm: React.FC<{ onSuccess: () => void }> = ({ onSuccess }) => {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [address, setAddress] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<ComplaintFormData>();

  useEffect(() => {
    if (profile?.name) {
      setValue('name', profile.name);
    }
  }, [profile, setValue]);

  const getGeolocation = () => {
    if (navigator.geolocation) {
      setStatusMessage({ type: 'success', text: "Getting your location..." });
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lng: longitude });
          
          // Reverse geocoding
          try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
            const data = await response.json();
            if (data.display_name) {
              setAddress(data.display_name);
              setStatusMessage({ type: 'success', text: "Location and address tagged!" });
            } else {
              setStatusMessage({ type: 'success', text: "Location tagged!" });
            }
          } catch (err) {
            console.error("Reverse geocoding error:", err);
            setStatusMessage({ type: 'success', text: "Location tagged (address lookup failed)." });
          }
        },
        (error) => {
          console.error("Error getting location:", error);
          setStatusMessage({ type: 'error', text: "Could not get your location. Please enable GPS." });
        }
      );
    }
  };

  const onSubmit = async (data: ComplaintFormData) => {
    if (!profile) {
      console.error("Submission failed: User profile not loaded");
      return;
    }
    setLoading(true);

    try {
      console.log("Starting submission...");
      
      console.log("Adding document to Firestore...");
      try {
        // Create a promise that rejects after 15 seconds
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error("Firestore operation timed out. Please check your internet connection.")), 15000)
        );

        const addDocPromise = addDoc(collection(db, 'complaints'), {
          userId: profile.uid,
          userName: data.name || profile.name || 'Anonymous',
          category: data.category,
          description: data.description,
          status: 'Submitted',
          location: location ? {
            latitude: location.lat,
            longitude: location.lng,
            address: address || null
          } : null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });

        await Promise.race([addDocPromise, timeoutPromise]);
        console.log("Document added successfully");
      } catch (firestoreError: any) {
        if (firestoreError.message.includes("timed out")) {
          throw firestoreError;
        }
        throw handleFirestoreError(firestoreError, OperationType.WRITE, 'complaints');
      }

      reset();
      setLocation(null);
      setAddress(null);
      onSuccess();
    } catch (error: any) {
      console.error("Error submitting complaint:", error);
      let message = "Failed to submit complaint. Please try again.";
      try {
        const parsed = JSON.parse(error.message);
        if (parsed.error.includes('permission-denied')) {
          message = "Permission denied. Please ensure you are logged in correctly.";
        }
      } catch (e) {
        message = error.message || message;
      }
      // Using console.error instead of alert as per iframe restrictions
      console.error("User Notification:", message);
      setStatusMessage({ type: 'error', text: message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 glass-card p-8 rounded-3xl">
      <div className="space-y-2">
        <label className="text-sm font-semibold text-slate-700 uppercase tracking-wider">Full Name</label>
        <div className="relative">
          <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            {...register('name', { required: true })}
            className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
            placeholder="Enter your name"
          />
        </div>
        {errors.name && <span className="text-xs text-red-500">Please enter your name</span>}
      </div>

      <div className="space-y-2">
        <label className="text-sm font-semibold text-slate-700 uppercase tracking-wider">Category</label>
        <select
          {...register('category', { required: true })}
          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
        >
          <option value="">Select a category</option>
          {CATEGORIES.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
        {errors.category && <span className="text-xs text-red-500">Please select a category</span>}
      </div>

      <div className="space-y-2">
        <label className="text-sm font-semibold text-slate-700 uppercase tracking-wider">Description</label>
        <textarea
          {...register('description', { required: true, minLength: 10 })}
          rows={4}
          placeholder="Describe the issue in detail..."
          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all resize-none"
        />
        {errors.description && <span className="text-xs text-red-500">Description must be at least 10 characters</span>}
      </div>

      <div className="grid grid-cols-1 gap-4">
        <button
          type="button"
          onClick={getGeolocation}
          className={cn(
            "flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 transition-all w-full",
            location 
              ? "bg-emerald-50 border-emerald-200 text-emerald-700" 
              : "bg-slate-50 border-slate-100 text-slate-600 hover:border-slate-200"
          )}
        >
          <MapPin className="w-5 h-5" />
          {location ? "Location Tagged" : "Tag Location"}
        </button>
      </div>

      {address && (
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex gap-3 items-start">
          <MapPin className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Detected Address</p>
            <p className="text-xs text-slate-600 leading-relaxed">{address}</p>
          </div>
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all disabled:opacity-50"
      >
        {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
        SUBMIT REPORT
      </button>

      {statusMessage && (
        <div className={cn(
          "p-4 rounded-xl text-sm font-bold flex items-center justify-center gap-3 animate-in fade-in slide-in-from-top-2",
          statusMessage.type === 'success' ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
        )}>
          {statusMessage.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <X className="w-5 h-5" />}
          {statusMessage.text}
        </div>
      )}
    </form>
  );
};
