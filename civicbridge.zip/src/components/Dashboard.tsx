import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Complaint, ComplaintStatus, STATUS_STAGES } from '../types';
import { useAuth } from '../AuthContext';
import { StatusTracker } from './StatusTracker';
import { format } from 'date-fns';
import { Search, Filter, MessageSquare, User, Calendar, MapPin, ExternalLink } from 'lucide-react';
import { cn } from '../lib/utils';

export const Dashboard: React.FC = () => {
  const { profile, isOfficial } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<ComplaintStatus | 'All'>('All');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'complaints'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint));
      setComplaints(data);
      setLoading(false);
    }, (error) => {
      console.error("Firestore Error (Dashboard):", error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const [remarks, setRemarks] = useState<Record<string, string>>({});

  const updateStatus = async (id: string, status: ComplaintStatus) => {
    try {
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Update timed out")), 10000)
      );
      
      const updatePromise = updateDoc(doc(db, 'complaints', id), {
        status,
        updatedAt: new Date().toISOString(),
        assignedTo: profile?.uid || null,
        remarks: remarks[id] || ''
      });

      await Promise.race([updatePromise, timeoutPromise]);
      // Clear local remarks for this ID after success
      setRemarks(prev => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Failed to update status. Please check your connection.");
    }
  };

  const filteredComplaints = complaints.filter(c => {
    const matchesFilter = filter === 'All' || c.status === filter;
    const matchesSearch = c.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         c.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         c.userName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const stats = {
    total: complaints.length,
    resolved: complaints.filter(c => c.status === 'Resolved').length,
    pending: complaints.filter(c => c.status !== 'Resolved').length,
    inProgress: complaints.filter(c => c.status === 'In Progress').length
  };

  if (loading) return <div className="flex justify-center p-12"><div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-8">
      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Issues', value: stats.total, color: 'bg-slate-100 text-slate-700' },
          { label: 'Resolved', value: stats.resolved, color: 'bg-emerald-100 text-emerald-700' },
          { label: 'In Progress', value: stats.inProgress, color: 'bg-blue-100 text-blue-700' },
          { label: 'Pending', value: stats.pending, color: 'bg-amber-100 text-amber-700' },
        ].map((stat, i) => (
          <div key={i} className={cn("p-4 rounded-2xl border border-transparent flex flex-col gap-1", stat.color)}>
            <span className="text-[10px] font-bold uppercase tracking-widest opacity-70">{stat.label}</span>
            <span className="text-2xl font-black">{stat.value}</span>
          </div>
        ))}
      </div>

      {/* Progress Overview */}
      <div className="glass-card p-6 rounded-3xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-widest">Resolution Progress</h3>
          <span className="text-sm font-bold text-emerald-600">
            {stats.total > 0 ? Math.round((stats.resolved / stats.total) * 100) : 0}% Complete
          </span>
        </div>
        <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-emerald-500 transition-all duration-1000" 
            style={{ width: `${stats.total > 0 ? (stats.resolved / stats.total) * 100 : 0}%` }}
          />
        </div>
        <p className="text-xs text-slate-500">
          {stats.resolved} out of {stats.total} reported issues have been successfully resolved.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between glass-card p-4 rounded-3xl">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search complaints..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
          <button 
            onClick={() => setFilter('All')}
            className={cn("px-4 py-2 rounded-lg text-sm font-medium transition-all", filter === 'All' ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200")}
          >
            All
          </button>
          {STATUS_STAGES.map(stage => (
            <button
              key={stage}
              onClick={() => setFilter(stage)}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all",
                filter === stage ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              )}
            >
              {stage}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {filteredComplaints.map((complaint) => (
          <div key={complaint.id} className="glass-card rounded-3xl overflow-hidden hover:shadow-2xl transition-all duration-300">
            <div className="p-6">
              <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-bold uppercase rounded tracking-wider">
                      {complaint.category}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">#{complaint.id.slice(0, 8)}</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">{complaint.description.slice(0, 100)}{complaint.description.length > 100 ? '...' : ''}</h3>
                </div>
                <div className="flex items-center gap-4 text-sm text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <User className="w-4 h-4" />
                    <span>{complaint.userName}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" />
                    <span>{format(new Date(complaint.createdAt), 'MMM d, yyyy')}</span>
                  </div>
                </div>
              </div>

              <StatusTracker currentStatus={complaint.status} />

              <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-slate-50">
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Location</h4>
                  {complaint.location ? (
                    <div className="space-y-2">
                      <div className="flex items-start gap-2 text-slate-600 text-sm">
                        <MapPin className="w-4 h-4 mt-0.5 shrink-0 text-emerald-600" />
                        <div className="space-y-1">
                          {complaint.location.address ? (
                            <p className="font-medium leading-relaxed">{complaint.location.address}</p>
                          ) : (
                            <p className="font-mono text-xs">
                              {complaint.location.latitude.toFixed(4)}, {complaint.location.longitude.toFixed(4)}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <span className="text-slate-400 italic text-sm">No location tagged</span>
                  )}
                </div>

                <div className="flex flex-col gap-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Official Actions</h4>
                  <div className="space-y-3">
                    <textarea
                      placeholder="Add official remarks or resolution notes..."
                      value={remarks[complaint.id] || complaint.remarks || ''}
                      onChange={(e) => setRemarks(prev => ({ ...prev, [complaint.id]: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg bg-slate-50 border border-slate-100 text-sm outline-none focus:ring-2 focus:ring-emerald-500 min-h-[80px] resize-none"
                    />
                    <div className="flex flex-col sm:flex-row gap-2">
                      <select
                        value={complaint.status}
                        onChange={(e) => updateStatus(complaint.id, e.target.value as ComplaintStatus)}
                        className="flex-1 px-3 py-2 rounded-lg bg-slate-50 border-slate-200 text-sm font-semibold focus:ring-2 focus:ring-emerald-500 outline-none"
                      >
                        {STATUS_STAGES.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                      {complaint.status !== 'Resolved' && (
                        <button
                          onClick={() => updateStatus(complaint.id, 'Resolved')}
                          className="px-4 py-2 bg-emerald-600 text-white text-sm font-bold rounded-lg hover:bg-emerald-700 transition-all"
                        >
                          Mark as Resolved
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
