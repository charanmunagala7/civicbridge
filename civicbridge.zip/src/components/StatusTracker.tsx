import React from 'react';
import { CheckCircle2, Circle, Clock, AlertCircle, Hammer, CheckCircle } from 'lucide-react';
import { ComplaintStatus, STATUS_STAGES } from '../types';
import { cn } from '../lib/utils';

interface StatusTrackerProps {
  currentStatus: ComplaintStatus;
}

const STATUS_ICONS: Record<ComplaintStatus, React.ReactNode> = {
  'Submitted': <AlertCircle className="w-5 h-5" />,
  'Under Review': <Clock className="w-5 h-5" />,
  'Assigned': <Circle className="w-5 h-5" />,
  'In Progress': <Hammer className="w-5 h-5" />,
  'Resolved': <CheckCircle className="w-5 h-5" />,
};

export const StatusTracker: React.FC<StatusTrackerProps> = ({ currentStatus }) => {
  const currentIndex = STATUS_STAGES.indexOf(currentStatus);

  return (
    <div className="w-full py-6">
      <div className="flex items-center justify-between relative">
        {/* Progress Line */}
        <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 -translate-y-1/2 z-0" />
        <div 
          className="absolute top-1/2 left-0 h-0.5 bg-emerald-600 -translate-y-1/2 z-0 transition-all duration-500" 
          style={{ width: `${(currentIndex / (STATUS_STAGES.length - 1)) * 100}%` }}
        />

        {STATUS_STAGES.map((stage, index) => {
          const isCompleted = index < currentIndex;
          const isCurrent = index === currentIndex;
          const isPending = index > currentIndex;

          return (
            <div key={stage} className="flex flex-col items-center relative z-10">
              <div 
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300",
                  isCompleted && "bg-emerald-600 border-emerald-600 text-white",
                  isCurrent && "bg-white border-emerald-600 text-emerald-600 ring-4 ring-emerald-50",
                  isPending && "bg-white border-slate-300 text-slate-400"
                )}
              >
                {isCompleted ? <CheckCircle2 className="w-6 h-6" /> : STATUS_ICONS[stage]}
              </div>
              <span 
                className={cn(
                  "absolute top-12 text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap",
                  isCurrent ? "text-emerald-700" : "text-slate-500"
                )}
              >
                {stage}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
